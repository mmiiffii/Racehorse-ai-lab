# racehorse-ai-lab

30‑day lab to test a daily UK horse racing "bet of the day" picked by an OpenAI model.

## What this project does

- **You provide real candidates**: for each day, you input a short list of *real* UK race
  runners (course, time, horse, odds) into a JSON file.
- **The model picks ONE bet of the day** from that list and explains the logic.
- **You record the real result** (win/lose and SP).
- A CSV file tracks profit and ROI over time.
- A helper script prints a quick summary of past performance.
- GitHub Actions workflows:
  - Prepare today's candidate JSON file automatically.
  - Run the prediction automatically (or via a button click) and commit the result.

The three example days included in `data/predictions/` and `data/results/` are **dummy
demonstration data** so you can see the performance tracking working before your first
real live day. From the first day you run the scripts yourself, all races and results
are as real as the data you type in.

## Daily flow (live days)

1. Let the **Prepare Candidates** workflow run (or run `python src/fetch_racecards.py` locally)
   to create today's `data/raw/racecards/YYYY-MM-DD.json`.
2. Edit that JSON with **real UK races** and odds for today.
3. Run the **Daily Prediction** workflow (or `python src/make_prediction.py`) to generate
   the bet of the day and reasoning.
4. After the race, run `python src/fetch_results.py` to record win/lose + SP.
5. Run `python src/show_metrics.py` to see performance so far.
