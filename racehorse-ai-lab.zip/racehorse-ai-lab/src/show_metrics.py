import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
METRICS_FILE = ROOT / "data" / "metrics" / "summary.csv"


def main():
    if not METRICS_FILE.exists():
        print("No metrics file found yet at", METRICS_FILE)
        print("Place some results first using fetch_results.py.")
        return

    with METRICS_FILE.open("r", newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        rows = list(reader)

    if not rows:
        print("Metrics file has a header but no rows yet.")
        return

    total_bets = len(rows)
    wins = sum(1 for r in rows if r["result"] == "win")
    losses = sum(1 for r in rows if r["result"] == "lose")
    last = rows[-1]

    try:
        cum_profit = float(last["cum_profit_units"])
        roi_total = float(last["roi_total"])
    except (KeyError, ValueError):
        cum_profit = 0.0
        roi_total = 0.0

    print("=== Performance summary ===")
    print(f"Total bets: {total_bets}")
    print(f"Wins: {wins}, Losses: {losses}")
    win_rate = (wins / total_bets) * 100 if total_bets else 0.0
    print(f"Win rate: {win_rate:.1f}%")
    print(f"Cumulative profit (1 unit stakes): {cum_profit:.2f}")
    print(f"Average profit per bet (ROI): {roi_total:.3f} units")

    print("\nLast 5 bets:")
    for r in rows[-5:]:
        print(
            f"{r['date']} | {r['course']} {r['time']} | {r['horse']} | "
            f"{r['result']} | profit {r['profit_units']} (cum {r['cum_profit_units']})"
        )


if __name__ == "__main__":
    main()
